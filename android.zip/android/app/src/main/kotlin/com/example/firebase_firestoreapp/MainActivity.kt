package com.example.firebase_firestoreapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
